//! Launcher core: version manifest, launch arguments. Exposed to Kotlin via UniFFI.

use serde::Deserialize;

uniffi::setup_scaffolding!();

const MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

#[derive(Debug, thiserror::Error, uniffi::Error)]
pub enum CoreError {
    #[error("network error: {0}")]
    Network(String),
    #[error("parse error: {0}")]
    Parse(String),
}

impl From<reqwest::Error> for CoreError {
    fn from(e: reqwest::Error) -> Self {
        CoreError::Network(e.to_string())
    }
}

#[derive(Debug, Deserialize)]
struct RawManifest {
    latest: RawLatest,
    versions: Vec<RawVersion>,
}

#[derive(Debug, Deserialize)]
struct RawLatest {
    release: String,
    snapshot: String,
}

#[derive(Debug, Deserialize)]
struct RawVersion {
    id: String,
    #[serde(rename = "type")]
    kind: String,
    url: String,
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct VersionInfo {
    pub id: String,
    pub kind: String,
    pub url: String,
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct VersionList {
    pub latest_release: String,
    pub latest_snapshot: String,
    pub versions: Vec<VersionInfo>,
}

/// Fetch Mojang's version manifest.
#[uniffi::export(async_runtime = "tokio")]
pub async fn fetch_versions() -> Result<VersionList, CoreError> {
    let raw: RawManifest = reqwest::get(MANIFEST_URL).await?.json().await?;
    Ok(VersionList {
        latest_release: raw.latest.release,
        latest_snapshot: raw.latest.snapshot,
        versions: raw
            .versions
            .into_iter()
            .map(|v| VersionInfo { id: v.id, kind: v.kind, url: v.url })
            .collect(),
    })
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct LaunchConfig {
    pub java_path: String,
    pub game_dir: String,
    pub assets_dir: String,
    pub version_id: String,
    pub main_class: String,
    pub classpath: Vec<String>,
    pub username: String,
    pub uuid: String,
    pub access_token: String,
    pub assets_index: String,
    pub max_memory_mb: u32,
    pub width: u32,
    pub height: u32,
}

/// Build the full command line (argv[0] is the java binary).
#[uniffi::export]
pub fn build_launch_args(cfg: LaunchConfig) -> Vec<String> {
    let mut args = vec![
        cfg.java_path,
        format!("-Xmx{}M", cfg.max_memory_mb),
        "-cp".to_string(),
        cfg.classpath.join(":"),
        cfg.main_class,
        "--username".to_string(),
        cfg.username,
        "--version".to_string(),
        cfg.version_id,
        "--gameDir".to_string(),
        cfg.game_dir,
        "--assetsDir".to_string(),
        cfg.assets_dir,
        "--assetIndex".to_string(),
        cfg.assets_index,
        "--uuid".to_string(),
        cfg.uuid,
        "--accessToken".to_string(),
        cfg.access_token,
        "--userType".to_string(),
        "legacy".to_string(),
        "--width".to_string(),
        cfg.width.to_string(),
        "--height".to_string(),
        cfg.height.to_string(),
    ];
    args.shrink_to_fit();
    args
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn launch_args_contain_memory_and_user() {
        let args = build_launch_args(LaunchConfig {
            java_path: "java".into(),
            game_dir: "/g".into(),
            assets_dir: "/a".into(),
            version_id: "1.21".into(),
            main_class: "net.minecraft.client.main.Main".into(),
            classpath: vec!["a.jar".into(), "b.jar".into()],
            username: "Steve".into(),
            uuid: "0".into(),
            access_token: "0".into(),
            assets_index: "17".into(),
            max_memory_mb: 2048,
            width: 854,
            height: 480,
        });
        assert!(args.contains(&"-Xmx2048M".to_string()));
        assert!(args.contains(&"Steve".to_string()));
        assert!(args.contains(&"a.jar:b.jar".to_string()));
    }
}
