use voxelane_core::fetch_versions;

#[tokio::main]
async fn main() {
    match fetch_versions().await {
        Ok(list) => {
            println!(
                "Latest release: {} | latest snapshot: {}",
                list.latest_release, list.latest_snapshot
            );
            println!("\nRecent releases:");
            for v in list.versions.iter().filter(|v| v.kind == "release").take(10) {
                println!("  {}  ->  {}", v.id, v.url);
            }
        }
        Err(e) => eprintln!("error: {e}"),
    }
}
