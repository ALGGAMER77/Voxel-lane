# Keep UniFFI-generated bindings and JNA once the Rust core is wired in.
-keep class uniffi.** { *; }
-keep class com.sun.jna.** { *; }
