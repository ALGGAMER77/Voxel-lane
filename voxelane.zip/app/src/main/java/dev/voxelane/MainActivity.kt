package dev.voxelane

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import dev.voxelane.controls.ControlEditor
import dev.voxelane.controls.ControlRepository
import dev.voxelane.ui.home.HomeScreen
import dev.voxelane.ui.home.Instance
import dev.voxelane.ui.theme.LauncherTheme
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val controls = ControlRepository(File(filesDir, "controls"))

        setContent {
            LauncherTheme {
                var editing by remember { mutableStateOf(false) }
                if (editing) {
                    ControlEditor(
                        initial = controls.load("Default"),
                        onSave = { controls.save(it); editing = false },
                    )
                } else {
                    HomeScreen(
                        // Placeholder until the instance store is wired to the Rust core.
                        instances = listOf(Instance("1", "Survival", "1.21.1", "Vanilla")),
                        onLaunch = { /* TODO: start the JVM via the runtime layer */ },
                        onEditControls = { editing = true },
                    )
                }
            }
        }
    }
}
