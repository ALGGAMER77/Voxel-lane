package dev.voxelane.controls

import kotlinx.serialization.Serializable

/** Positions and sizes are fractions of the screen so layouts survive any resolution. */
@Serializable
enum class ControlType { BUTTON, TOGGLE, JOYSTICK, LOOK_AREA }

@Serializable
data class ControlElement(
    val id: String,
    val type: ControlType,
    val label: String,
    /** Key or mouse action sent to the game, e.g. "W", "SPACE", "MOUSE_LEFT". */
    val key: String = "",
    val x: Float,
    val y: Float,
    /** Edge length as a fraction of screen height. */
    val size: Float = 0.14f,
    val opacity: Float = 0.6f,
)

@Serializable
data class ControlLayout(
    val name: String,
    val elements: List<ControlElement>,
) {
    fun withElement(updated: ControlElement) =
        copy(elements = elements.map { if (it.id == updated.id) updated else it })

    fun withoutElement(id: String) = copy(elements = elements.filterNot { it.id == id })

    fun withAdded(element: ControlElement) = copy(elements = elements + element)

    companion object {
        val Default = ControlLayout(
            name = "Default",
            elements = listOf(
                ControlElement("move", ControlType.JOYSTICK, "Move", x = 0.06f, y = 0.55f, size = 0.34f),
                ControlElement("look", ControlType.LOOK_AREA, "Look", x = 0.5f, y = 0.0f, size = 1f, opacity = 0f),
                ControlElement("jump", ControlType.BUTTON, "Jump", "SPACE", x = 0.85f, y = 0.62f, size = 0.16f),
                ControlElement("attack", ControlType.BUTTON, "Hit", "MOUSE_LEFT", x = 0.72f, y = 0.4f, size = 0.16f),
                ControlElement("use", ControlType.BUTTON, "Use", "MOUSE_RIGHT", x = 0.85f, y = 0.38f, size = 0.16f),
                ControlElement("sneak", ControlType.TOGGLE, "Sneak", "SHIFT", x = 0.72f, y = 0.72f, size = 0.14f),
                ControlElement("inv", ControlType.BUTTON, "Inv", "E", x = 0.46f, y = 0.86f, size = 0.12f),
            ),
        )
    }
}

/** What the game side implements; the overlay only talks to this. */
interface InputSink {
    fun onKey(key: String, pressed: Boolean)
    fun onMove(dx: Float, dy: Float)
    fun onLook(dx: Float, dy: Float)
}
