package dev.voxelane.controls

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Drag elements to move them, tap to select, then adjust size/opacity or delete. */
@Composable
fun ControlEditor(
    initial: ControlLayout,
    onSave: (ControlLayout) -> Unit,
    modifier: Modifier = Modifier,
) {
    var layout by remember { mutableStateOf(initial) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = layout.elements.firstOrNull { it.id == selectedId }
    val density = LocalDensity.current

    Box(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()

            layout.elements.filter { it.type != ControlType.LOOK_AREA }.forEach { el ->
                val sizePx = el.size * h
                val isSelected = el.id == selectedId
                Box(
                    modifier = Modifier
                        .offset { IntOffset((el.x * w).roundToInt(), (el.y * h).roundToInt()) }
                        .size(with(density) { sizePx.toDp() })
                        .alpha(el.opacity.coerceAtLeast(0.3f))
                        .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        .border(
                            if (isSelected) 3.dp else 1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            CircleShape,
                        )
                        .pointerInput(el.id) {
                            detectDragGestures(onDragStart = { selectedId = el.id }) { change, drag ->
                                change.consume()
                                val current = layout.elements.first { it.id == el.id }
                                val nx = (current.x + drag.x / w).coerceIn(0f, 1f - current.size * h / w)
                                val ny = (current.y + drag.y / h).coerceIn(0f, 1f - current.size)
                                layout = layout.withElement(current.copy(x = nx, y = ny))
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) { Text(el.label, style = MaterialTheme.typography.labelMedium) }
            }
        }

        FloatingActionButton(
            onClick = { onSave(layout) },
            modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
        ) { Icon(Icons.Filled.Check, contentDescription = "Save layout") }

        Row(
            Modifier.align(Alignment.TopStart).padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilledTonalButton(onClick = {
                val id = "btn_${System.nanoTime()}"
                layout = layout.withAdded(
                    ControlElement(id, ControlType.BUTTON, "Key", "F", x = 0.4f, y = 0.4f),
                )
                selectedId = id
            }) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("Add button")
            }
        }

        if (selected != null) {
            Card(Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth(0.6f)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(selected.label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            layout = layout.withoutElement(selected.id)
                            selectedId = null
                        }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                    Text("Size", style = MaterialTheme.typography.labelSmall)
                    Slider(
                        value = selected.size,
                        onValueChange = { layout = layout.withElement(selected.copy(size = it)) },
                        valueRange = 0.08f..0.4f,
                    )
                    Text("Opacity", style = MaterialTheme.typography.labelSmall)
                    Slider(
                        value = selected.opacity,
                        onValueChange = { layout = layout.withElement(selected.copy(opacity = it)) },
                        valueRange = 0.1f..1f,
                    )
                }
            }
        }
    }
}
