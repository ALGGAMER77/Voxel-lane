package dev.voxelane.controls

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/** Stores each layout as a JSON file so profiles are easy to back up and share. */
class ControlRepository(private val dir: File) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    init { dir.mkdirs() }

    fun list(): List<String> =
        dir.listFiles { f -> f.extension == "json" }?.map { it.nameWithoutExtension }?.sorted().orEmpty()

    fun load(name: String): ControlLayout =
        runCatching { json.decodeFromString<ControlLayout>(File(dir, "$name.json").readText()) }
            .getOrDefault(ControlLayout.Default)

    fun save(layout: ControlLayout) {
        File(dir, "${layout.name}.json").writeText(json.encodeToString(layout))
    }

    fun delete(name: String) {
        File(dir, "$name.json").delete()
    }
}
