package dev.voxelane.controls

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.hypot
import kotlin.math.roundToInt

/** In-game overlay: renders the layout and forwards touches to [sink]. */
@Composable
fun ControlOverlay(layout: ControlLayout, sink: InputSink, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        layout.elements.forEach { el ->
            when (el.type) {
                ControlType.LOOK_AREA -> LookArea(sink)
                ControlType.BUTTON -> HoldButton(el, w, h, sink, sticky = false)
                ControlType.TOGGLE -> HoldButton(el, w, h, sink, sticky = true)
                ControlType.JOYSTICK -> Joystick(el, w, h, sink)
            }
        }
    }
}

@Composable
private fun LookArea(sink: InputSink) {
    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            detectDragGestures { change, drag ->
                change.consume()
                sink.onLook(drag.x, drag.y)
            }
        },
    )
}

@Composable
private fun HoldButton(el: ControlElement, w: Float, h: Float, sink: InputSink, sticky: Boolean) {
    val density = LocalDensity.current
    val sizePx = el.size * h
    var active by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .offset { IntOffset((el.x * w).roundToInt(), (el.y * h).roundToInt()) }
            .size(with(density) { sizePx.toDp() })
            .alpha(el.opacity)
            .background(
                if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                CircleShape,
            )
            .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
            .pointerInput(el.id) {
                awaitEachGesture {
                    awaitFirstDown().consume()
                    if (sticky) {
                        active = !active
                        sink.onKey(el.key, active)
                        waitForUpOrCancellation()
                    } else {
                        active = true
                        sink.onKey(el.key, true)
                        waitForUpOrCancellation()
                        active = false
                        sink.onKey(el.key, false)
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) { Text(el.label, style = MaterialTheme.typography.labelMedium) }
}

@Composable
private fun Joystick(el: ControlElement, w: Float, h: Float, sink: InputSink) {
    val density = LocalDensity.current
    val sizePx = el.size * h
    var knob by remember { mutableStateOf(Offset.Zero) }
    val radius = sizePx / 2f
    Box(
        modifier = Modifier
            .offset { IntOffset((el.x * w).roundToInt(), (el.y * h).roundToInt()) }
            .size(with(density) { sizePx.toDp() })
            .alpha(el.opacity)
            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
            .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
            .pointerInput(el.id) {
                detectDragGestures(
                    onDragEnd = { knob = Offset.Zero; sink.onMove(0f, 0f) },
                    onDragCancel = { knob = Offset.Zero; sink.onMove(0f, 0f) },
                ) { change, drag ->
                    change.consume()
                    var next = knob + drag
                    val len = hypot(next.x, next.y)
                    if (len > radius) next = next * (radius / len)
                    knob = next
                    sink.onMove(next.x / radius, next.y / radius)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .offset { IntOffset(knob.x.roundToInt(), knob.y.roundToInt()) }
                .size(with(density) { (sizePx * 0.4f).toDp() })
                .background(MaterialTheme.colorScheme.primary, CircleShape),
        )
    }
}
