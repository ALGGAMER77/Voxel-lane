# Voxelane

Android launcher for Minecraft: Java Edition. Material 3 UI, Pojav-style touch controls, Rust core.

## Layout

- `core/`: Rust crate (versions, launch args), exposed to Kotlin through UniFFI
- `app/`: Android app (Kotlin, Jetpack Compose, Material 3)
  - `controls/`: layout model, JSON storage, in-game overlay, drag-and-drop editor
  - `ui/`: theme and screens

## Status

Working in source: Material 3 shell, control layout model/editor/overlay, Rust version fetch and launch-arg builder.

Not done yet:
- Wire the Rust core into the app (UniFFI bindings + cargo-ndk for arm64-v8a)
- Runtime layer: bundled ARM JRE, GL-to-GLES translation, LWJGL/GLFW bridge
- Downloads (client jar, libraries, assets), accounts (offline first, Microsoft later)
- Nothing here has been compiled or run yet

## Build (planned)

```
cd core && cargo test
cargo ndk -t arm64-v8a build --release
./gradlew :app:assembleDebug
```

## License

GPL-3.0-or-later, so Pojav-derived runtime pieces can be reused.
